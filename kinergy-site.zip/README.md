# Kinergy Solutions — React + Vite (Tailwind via CDN)

## Run locally
npm i
npm run dev

## Deploy to Vercel
- Framework Preset: **Vite**
- Output Directory: **dist**
- Root: `/`
- No env vars required

Logo path: `/public/kinergy-logo.png`