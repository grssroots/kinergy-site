import { useEffect, useState } from 'react'
const logo = '/kinergy-logo.png' // place your logo at /public/kinergy-logo.png

function devSelfCheck() {
  try {
    const BRANDS = ['Daikin','Mitsubishi Electric','Vaillant','Alpha','Samsung','GivEnergy']
    console.assert(BRANDS.length >= 6, 'Expect ≥6 brands')
    const pc = 'lu2 7xx'.toUpperCase()
    console.assert(pc === 'LU2 7XX', 'Postcode uppercase logic')
    console.assert('+447777381617'.startsWith('+44'), 'Phone uses +44 format')
  } catch(e) { console.warn('Kinergy devSelfCheck:', e) }
}
if (typeof window !== 'undefined') devSelfCheck()

export default function App() {
  const [postcode, setPostcode] = useState('')
  const [form, setForm] = useState({ name:'', email:'', phone:'', message:'' })
  const [errors, setErrors] = useState({})
  const year = new Date().getFullYear()

  useEffect(() => { console.debug('KinergyLanding mounted') }, [])

  const NAV = [
    { href:'#services', label:'Services' },
    { href:'#finance', label:'Finance' },
    { href:'#why', label:'Why' },
    { href:'#brands', label:'Brands' },
    { href:'#reviews', label:'Reviews' },
    { href:'#contact', label:'Contact' },
  ]

  const ACCREDITATIONS = ['MCS','RECC','TrustMark','F-Gas','Gas Safe','NICEIC','Daikin','Mitsubishi']
  const APPROVED_BRANDS = ['Daikin','Mitsubishi Electric','Vaillant','Alpha','Samsung','GivEnergy']

  function validateContact() {
    const next = {}
    if (!form.name.trim()) next.name = 'Name is required'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email'
    if (form.phone && !/^[+0-9 ()-]{7,}$/.test(form.phone)) next.phone = 'Check phone format'
    if (!form.message.trim()) next.message = 'Tell us a bit about the project'
    setErrors(next)
    return Object.keys(next).length === 0
  }
  function onSubmitContact(e){ e.preventDefault(); if (!validateContact()) return; alert('Thanks — we\'ll be in touch shortly.') }

  return (
    <div className="min-h-screen bg-black text-neutral-100 selection:bg-emerald-500/30">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context":"https://schema.org",
            "@type":"HVACBusiness",
            name:"Kinergy Solutions",
            url:"https://kinergysolutions.co.uk",
            areaServed:["Bedfordshire","Hertfordshire","Buckinghamshire","London"],
            email:"hello@kinergy.uk",
            telephone:"+44 7777 381617",
            address:{ "@type":"PostalAddress", streetAddress:"Unit 2 The Acres", addressLocality:"Luton", addressCountry:"GB" },
            openingHours:["Mo-Fr 08:00-18:00","Sa 09:00-13:00"],
            makesOffer:["Air Source Heat Pumps","Solar PV & Battery","Air Conditioning","Electrical","MVHR"]
          })
        }}
      />
      <div className="w-full bg-neutral-900/80 backdrop-blur border-b border-white/10">
        <div className="mx-auto max-w-7xl flex items-center justify-between py-2 px-4 text-xs md:text-sm">
          <div className="flex items-center gap-4">
            <a href="mailto:hello@kinergy.uk" className="opacity-90 hover:opacity-100">hello@kinergy.uk</a>
            <a href="tel:+447777381617" className="opacity-90 hover:opacity-100">07777 381 617</a>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <span className="rounded-full bg-emerald-600/20 px-3 py-1 text-emerald-400">MCS Ready</span>
            <span className="rounded-full bg-emerald-600/20 px-3 py-1 text-emerald-300">BUS £7,500</span>
            <span className="rounded-full bg-emerald-600/20 px-3 py-1 text-emerald-300">0% Finance*</span>
          </div>
        </div>
      </div>

      <header className="sticky top-0 z-40 bg-black/70 backdrop-blur border-b border-white/10">
        <div className="mx-auto max-w-7xl flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Kinergy Solutions" className="h-9 w-auto object-contain" loading="eager" />
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            {NAV.map(n => <a key={n.href} href={n.href} className="hover:text-emerald-400">{n.label}</a>)}
            <a href="#quote" className="rounded-xl bg-emerald-500 text-black px-4 py-2 font-semibold hover:bg-emerald-400 transition shadow">Free Quote</a>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(80rem_50rem_at_50%_-10%,rgba(16,185,129,0.18),transparent_60%)]" />
        <div className="mx-auto max-w-7xl px-4 py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <div style={{animation:'fadeIn 0.6s ease-out forwards'}} className="opacity-0">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight">
              Heat Pumps, Solar & HVAC for <span className="text-emerald-400">Beds • Herts • Bucks • London</span>
            </h1>
            <p className="mt-4 text-lg text-neutral-300">
              Itemised, MCS-aligned installs with obsessive attention to detail. We design, fit, commission, and care.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <a href="#quote" className="rounded-xl bg-emerald-500 text-black px-5 py-3 font-semibold hover:bg-emerald-400 shadow">Get a same-day estimate</a>
              <a href="#services" className="rounded-xl border border-white/20 px-5 py-3 font-semibold hover:border-emerald-400/60">Browse services</a>
            </div>
            <div className="mt-6 text-sm text-neutral-400">
              <span className="mr-3">• BUS grants up to £7,500</span>
              <span className="mr-3">• RECC • TrustMark • Gas Safe • F-Gas</span>
              <span>• Finance via FCA-authorised partners*</span>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl bg-neutral-900 p-6 ring-1 ring-white/10 shadow-xl">
              <div className="h-full w-full rounded-xl bg-[conic-gradient(at_70%_30%,_rgba(16,185,129,0.15),_transparent_40%)] grid place-items-center">
                <p className="text-xl text-neutral-300">Swap in ASHP / indoor unit hero image</p>
              </div>
            </div>
            <div className="absolute -bottom-6 -left-6 hidden md:block rounded-2xl bg-emerald-500 text-black px-4 py-3 shadow">
              <p className="text-sm font-semibold">MCS paperwork & BUS handled in-house</p>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="badges" className="py-10 border-t border-white/10 bg-neutral-950">
        <div className="mx-auto max-w-7xl px-4">
          <h2 id="badges" className="sr-only">Accreditations</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-6 items-center opacity-80">
            {ACCREDITATIONS.map(b => (
              <div key={b} className="h-10 bg-neutral-900 rounded-lg grid place-items-center text-xs font-medium text-neutral-300 ring-1 ring-white/10">{b}</div>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl font-bold tracking-tight">Services</h2>
          <p className="mt-2 text-neutral-300 max-w-2xl">Full-stack HVAC and renewables with clear scope, tidy installs, and data-driven commissioning.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              { title: 'Air Source Heat Pumps', blurb: 'MCS-aligned design, low-flow-temp emitters, controls set-up. BUS handled end-to-end.' },
              { title: 'Ground Source Heat Pumps', blurb: 'Borehole/ground loop partners, full system design, glycol fill & commission.' },
              { title: 'Solar PV & Battery', blurb: 'High-yield PV arrays, battery storage, export tariffs, smart monitoring dashboards.' },
              { title: 'Air Conditioning', blurb: 'Wall/ducted/multi-split. F-Gas certified with neat containment & condensate management.' },
              { title: 'MVHR Ventilation', blurb: 'Balanced fresh-air systems with filters & silencers, commissioned to spec.' },
              { title: 'Electrical', blurb: 'NICEIC works: heat-pump ready boards, EV charge points, rewires & EICs.' },
            ].map(s => (
              <div key={s.title} className="group rounded-2xl bg-neutral-950 p-6 shadow-sm ring-1 ring-white/10 hover:ring-emerald-500/50 transition">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-semibold text-white">{s.title}</h3>
                  <span className="text-sm text-neutral-400 group-hover:text-emerald-400">Learn more →</span>
                </div>
                <p className="mt-2 text-sm text-neutral-300">{s.blurb}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="finance" className="py-20 bg-neutral-950">
        <div className="mx-auto max-w-7xl px-4 grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Boiler Upgrade Scheme (BUS)</h2>
            <p className="mt-3 text-neutral-300">
              UK homeowners can claim up to <strong>£7,500</strong> toward a heat pump. We manage the voucher from
              application to redemption: eligibility, design, MCS certificates, and evidence pack.
            </p>
            <ul className="mt-4 space-y-2 text-neutral-300 text-sm">
              <li>• EPC with no outstanding loft/cavity recommendations</li>
              <li>• Property in England or Wales</li>
              <li>• Replacing fossil boiler or direct electric (most cases)</li>
              <li>• System designed for low flow temps (SCOP-optimised)</li>
            </ul>
          </div>
          <div className="rounded-2xl bg-neutral-900 p-6 ring-1 ring-white/10">
            <h3 className="text-xl font-semibold mb-2">Finance Options</h3>
            <p className="text-neutral-300 text-sm">Via FCA-authorised partners. Credit subject to status.</p>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl bg-black p-4 ring-1 ring-white/10">
                <p className="font-medium">0% up to 12 months</p>
                <p className="text-neutral-400">On selected installs</p>
              </div>
              <div className="rounded-xl bg-black p-4 ring-1 ring-white/10">
                <p className="font-medium">Low-rate 2–5 yrs</p>
                <p className="text-neutral-400">Spread the cost</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="why" className="py-20 bg-neutral-950">
        <div className="mx-auto max-w-7xl px-4 grid gap-10 md:grid-cols-2 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Why Kinergy</h2>
            <ul className="mt-4 space-y-3 text-neutral-300">
              <li>Upfront, itemised quotes — no surprises.</li>
              <li>MCS design pack, commissioning sheets, and handover included.</li>
              <li>Trusted brands only: Daikin, Mitsubishi, Vaillant, Alpha and more.</li>
              <li>Local aftercare across Beds, Herts, Bucks & London.</li>
              <li>Finance via FCA-authorised partners.*</li>
            </ul>
            <p className="mt-4 text-xs text-neutral-500">*Subject to status. Credit broker, not a lender.</p>
          </div>
          <div className="rounded-2xl bg-neutral-900 aspect-[4/3] grid place-items-center ring-1 ring-white/10">
            <p className="text-neutral-400">Swap in install gallery / case studies</p>
          </div>
        </div>
      </section>

      <section id="brands" className="py-16 bg-black border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-2xl font-bold">Approved Brands</h2>
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {APPROVED_BRANDS.map(brand => (
              <div key={brand} className="h-12 rounded-lg bg-neutral-950 grid place-items-center text-sm text-neutral-300 ring-1 ring-white/10">{brand}</div>
            ))}
          </div>
        </div>
      </section>

      <section id="reviews" className="py-20 bg-neutral-950">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-2xl font-bold">What customers say</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {[
              { name:'Laura M.', text:'Kinergy stepped in late notice and commissioned our ASHP the next day. Professional and calm under pressure.' },
              { name:'Gareth J.', text:'Meticulous workmanship. The system runs whisper-quiet and bills dropped immediately.' },
              { name:'Elise C.', text:'Clear comms, tidy site, and handover that made sense. Would recommend.' },
            ].map((r,i) => (
              <figure key={i} className="rounded-2xl bg-black p-6 shadow-sm ring-1 ring-white/10">
                <blockquote className="text-neutral-300">“{r.text}”</blockquote>
                <figcaption className="mt-4 text-sm font-medium text-white">{r.name}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4 grid md:grid-cols-2 gap-10">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Get in touch</h2>
            <p className="mt-2 text-neutral-300">Unit 2 The Acres, Luton • hello@kinergy.uk • 07777 381 617</p>
            <ul className="mt-6 space-y-2 text-neutral-400 text-sm">
              <li>Mon–Fri 8:00–18:00, Sat 9:00–13:00</li>
              <li>Coverage: Luton, Bedford, Milton Keynes, St Albans, Watford, North London</li>
              <li>Company No. 00000000 • FCA broker statement if applicable</li>
            </ul>
          </div>
          <form onSubmit={onSubmitContact} noValidate className="bg-neutral-950 p-6 rounded-2xl shadow-sm ring-1 ring-white/10">
            <div className="grid gap-4">
              <div>
                <label htmlFor="name" className="text-sm">Name</label>
                <input id="name" className="mt-1 w-full rounded-xl border border-white/10 bg-black px-4 py-3 text-white placeholder:text-neutral-500 focus:outline-none" placeholder="Your name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
                {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="email" className="text-sm">Email</label>
                <input id="email" type="email" className="mt-1 w-full rounded-xl border border-white/10 bg-black px-4 py-3 text-white placeholder:text-neutral-500 focus:outline-none" placeholder="you@example.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
                {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
              </div>
              <div>
                <label htmlFor="phone" className="text-sm">Phone</label>
                <input id="phone" className="mt-1 w-full rounded-xl border border-white/10 bg-black px-4 py-3 text-white placeholder:text-neutral-500 focus:outline-none" placeholder="Optional" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
                {errors.phone && <p className="mt-1 text-xs text-red-400">{errors.phone}</p>}
              </div>
              <div>
                <label htmlFor="msg" className="text-sm">Project details</label>
                <textarea id="msg" className="mt-1 w-full rounded-xl border border-white/10 bg-black px-4 py-3 text-white placeholder:text-neutral-500 focus:outline-none min-h-[120px]" placeholder="Property type, current heating, timeline" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} />
                {errors.message && <p className="mt-1 text-xs text-red-400">{errors.message}</p>}
              </div>
              <button className="rounded-xl bg-emerald-500 text-black px-5 py-3 font-semibold hover:bg-emerald-400">Send</button>
            </div>
          </form>
        </div>
      </section>

      <footer className="bg-neutral-950 text-neutral-300">
        <div className="mx-auto max-w-7xl px-4 py-10 grid md:grid-cols-4 gap-8">
          <div>
            <img src={logo} alt="Kinergy Solutions" className="h-8 mb-3" loading="lazy" />
            <p className="text-sm opacity-80 max-w-xs">Renewables & HVAC specialists for Bedfordshire, Hertfordshire, Buckinghamshire and London.</p>
          </div>
          <div>
            <h3 className="font-semibold">Core Services</h3>
            <ul className="mt-3 space-y-2 text-sm opacity-90">
              <li><a href="#services">Air Source Heat Pumps</a></li>
              <li><a href="#services">Solar PV & Battery</a></li>
              <li><a href="#services">Air Conditioning</a></li>
              <li><a href="#services">Electrical</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold">Company</h3>
            <ul className="mt-3 space-y-2 text-sm opacity-90">
              <li><a href="#why">About</a></li>
              <li><a href="#reviews">Reviews</a></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="#finance">Finance & Grants</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold">Legal</h3>
            <ul className="mt-3 space-y-2 text-sm opacity-90">
              <li>Terms & Conditions</li>
              <li>Privacy Policy</li>
              <li>Cookies</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col sm:flex-row items-center justify-between text-xs opacity-80">
            <p>© {year} Kinergy Solutions. All rights reserved.</p>
            <p>FCA broker statement if applicable. Credit subject to status.</p>
          </div>
        </div>
      </footer>

      <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  )
}